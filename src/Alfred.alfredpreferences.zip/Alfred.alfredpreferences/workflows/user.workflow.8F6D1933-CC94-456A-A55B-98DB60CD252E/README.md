# UUIDGen for Alfred Workflow

Simple Alfred Workflow to generate UUIDs.

## Usage

Place new UUID at Cursor:

	uuid [Enter]
    
Place new UUID on Clipboard:

	uuid [CMD-Enter]